package com.company;

import java.util.Date;

public class FreightTrain extends Car{

    private int liftingCapacity;

    protected FreightTrain(){
        super();
    }

    protected FreightTrain(CarBrand carBrand,String name, int carId,String color,Date dateOfIssue){
        super(carBrand,name,carId,color,dateOfIssue);
}

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("FreightTrain{");
        sb.append("carBrand=").append(carBrand);
        sb.append(", name='").append(name).append('\'');
        sb.append(", carId=").append(carId);
        sb.append(", color='").append(color).append('\'');
        sb.append(", dateOfIssue=").append(dateOfIssue);
        sb.append(", liftingCapacity=").append(liftingCapacity);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public void startEngine() {
        super.startEngine();
    }

    @Override
    public void stopEngine() {
        super.stopEngine();
    }

    @Override
    public void move() {

    }
}
