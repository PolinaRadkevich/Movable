package com.company;

import java.util.Calendar;



public class Main {

    public static void main(String[] args) {

        Calendar calendar = Calendar.getInstance();
        calendar.set(2000,02,03);

        Car myCar = new PassengerCar(CarBrand.MAZDA, "Mazda 6", 12458, "white", calendar.getTime() );

        Calendar calendar1 = Calendar.getInstance();
        calendar1.set(2020,02,03);

        Car car = new FreightTrain(CarBrand.LADA,"LadaTrain",45987,"red",calendar1.getTime());



    }
}


