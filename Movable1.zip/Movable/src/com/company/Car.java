package com.company;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;


public class Car implements Movable {

    protected CarBrand carBrand;
    protected String name;
    protected int carId;
    protected String color;
    protected Date dateOfIssue;
    protected Engine engine;


    public Car(CarBrand carBrand, String name, int carId, String color, Date dateOfIssue) {
        this.carBrand = carBrand;
        this.name = name;
        this.carId = carId;
        this.color = color;
        this.dateOfIssue = dateOfIssue;
        this.engine = engine;
        engine.isWorking = true;

    }

    public Car() {

    }

    public void startEngine() {

        System.out.println("Engine is started!");
    }

    public void stopEngine() {

        System.out.println("Engine is stopped");
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Car{");
        sb.append("carBrand=").append(carBrand);
        sb.append(", name='").append(name).append('\'');
        sb.append(", carId=").append(carId);
        sb.append(", color='").append(color).append('\'');
        sb.append(", dateOfIssue=").append(dateOfIssue);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Car)) return false;
        Car car = (Car) o;
        return carId == car.carId && carBrand == car.carBrand && Objects.equals(name, car.name) && Objects.equals(color, car.color) && Objects.equals(engine, car.engine) && Objects.equals(dateOfIssue, car.dateOfIssue);
    }

    @Override
    public int hashCode() {
        return Objects.hash(carBrand, name, carId, color, engine, dateOfIssue);
    }

    protected class Engine {

        private boolean isWorking;
        private int cylindersAmount;
        private int power;

        public Engine(boolean isWorking, int cylindersAmount, int power) {
            this.isWorking = isWorking;
            this.cylindersAmount = cylindersAmount;
            this.power = power;
        }

        public boolean isWorking() {

            return isWorking;
        }

        public void setWorking(boolean working) {

            isWorking = working;
        }

        public int getCylindersAmount() {

            return cylindersAmount;
        }

        public void setCylindersAmount(int cylindersAmount) {

            this.cylindersAmount = cylindersAmount;
        }

        public int getPower() {

            return power;
        }

        public void setPower(int power) {

            this.power = power;
        }

    }

    public String getDateOfIssue(){
        final String DATE_FORMAT = "yyyy.MM.dd";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd");
        String formattedDate = simpleDateFormat.format(dateOfIssue);
        return formattedDate;
    }

}
