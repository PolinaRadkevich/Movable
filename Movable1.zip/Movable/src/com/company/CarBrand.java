package com.company;

import java.util.Date;

public enum CarBrand {
    MERCEDES("Mercedes", "Germany",new Date() ),
    BMW("BMW", "Germany", new Date()),
    MAZDA("Mazda", "Japan",new Date()),
    TESLA("Tesla", "USA", new Date()),
    LADA("Lada", "Russia", new Date());

    private String name;
    private String country;
    private Date date;


    CarBrand(String name, String country, Date date) {
        this.name = name;
        this.country = country;
        this.date = date;
     }

    public void brandInformation() {
        System.out.println("Информация о марке " + this.name + " " + this.country);
    }

    public String toString() {
        return name + " " + country + " " + date;
    }

    public String getName() {
        return name;
    }

    public String getCountry() {
        return country;
    }

    public Date getDate() {
        return date;
    }
}

