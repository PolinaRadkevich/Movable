package com.company;

public class Bike implements Movable {

    private int speedPosition;

    public void move() {
        speedPosition++;
        System.out.println("Actual speed is: " + speedPosition);
    }

    public void move(int value) {
        speedPosition += value;
        System.out.println("Bike speed now is: " + speedPosition + "(greater on " + value + ")");
    }
}

