package com.company;

public interface Movable {
    default void move() {

        System.out.println("Movable is moving!");
    }
}
