package com.company;

import java.util.Date;


public class PassengerCar extends Car{

    private int placesAmount;

    protected PassengerCar(){
        super();
}
    protected PassengerCar(CarBrand carBrand, String name, int carId, String color, Date dateOfIssue){
        super(carBrand, name,carId,color,dateOfIssue);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PassengerCar{");
        sb.append("carBrand=").append(carBrand);
        sb.append(", name='").append(name).append('\'');
        sb.append(", carId=").append(carId);
        sb.append(", color='").append(color).append('\'');
        sb.append(", dateOfIssue=").append(dateOfIssue);
        sb.append(", placesAmount=").append(placesAmount);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public void startEngine() {
        super.startEngine();
        System.out.println("The engine is started in the passenger car");
    }

    @Override
    public void stopEngine() {
        super.stopEngine();
        System.out.println("The engine is stopped in the passenger car");
    }

    @Override
    public void move() {
        System.out.println("Passenger car is moving! " + super.carBrand);
    }
}

